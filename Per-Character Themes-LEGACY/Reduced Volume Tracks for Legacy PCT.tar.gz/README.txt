These are replacement OGGs for in case you think that Sonic's tracks are too loud. Specifically, these versions are quieter by three decibels. 
